const jwt = require('jsonwebtoken');
const ErrorResponse = require('../utils/ErrorResponse');
const User = require('../models/User');

// Protect routes
exports.protect = async (req, res, next) => {
  let token;

  // Check for token in cookies first, then Authorization header
  if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  } else if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  }

  // Make sure token exists
  if (!token) {
    // For view routes, redirect to login
    if (req.originalUrl && !req.originalUrl.startsWith('/api/')) {
      return res.redirect('/login');
    }
    return next(new ErrorResponse('Not authorized to access this route', 401));
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id);

    if (!req.user) {
      if (req.originalUrl && !req.originalUrl.startsWith('/api/')) {
        return res.redirect('/login');
      }
      return next(new ErrorResponse('User not found', 401));
    }

    // Check if user is banned/suspended
    if (req.user.status === 'banned') {
      res.cookie('token', 'none', { expires: new Date(Date.now() + 1000), httpOnly: true });
      return next(new ErrorResponse('Your account has been banned', 403));
    }

    if (req.user.status === 'suspended') {
      return next(new ErrorResponse('Your account has been suspended. Contact support.', 403));
    }

    next();
  } catch (err) {
    if (req.originalUrl && !req.originalUrl.startsWith('/api/')) {
      return res.redirect('/login');
    }
    return next(new ErrorResponse('Not authorized to access this route', 401));
  }
};

// Grant access to specific roles
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      if (req.originalUrl && !req.originalUrl.startsWith('/api/')) {
        return res.redirect('/dashboard');
      }
      return next(new ErrorResponse(`User role '${req.user.role}' is not authorized to access this route`, 403));
    }
    next();
  };
};
