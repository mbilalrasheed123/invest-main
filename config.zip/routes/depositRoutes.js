const express = require('express');
const router = express.Router();
const { createDeposit, getMyDeposits } = require('../controllers/depositController');
const { protect } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.use(protect);

router.post('/', upload.single('paymentProof'), createDeposit);
router.get('/my', getMyDeposits);

module.exports = router;
