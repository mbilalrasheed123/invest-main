const express = require('express');
const router = express.Router();
const { getDashboard, getProfile, updateProfile, updatePassword } = require('../controllers/userController');
const { protect } = require('../middleware/auth');

router.use(protect); // All routes require auth

router.get('/dashboard', getDashboard);
router.get('/profile', getProfile);
router.put('/profile', updateProfile);
router.put('/updatepassword', updatePassword);

module.exports = router;
