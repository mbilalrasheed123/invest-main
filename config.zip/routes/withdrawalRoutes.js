const express = require('express');
const router = express.Router();
const { createWithdrawal, getMyWithdrawals } = require('../controllers/withdrawalController');
const { protect } = require('../middleware/auth');

router.use(protect);

router.post('/', createWithdrawal);
router.get('/my', getMyWithdrawals);

module.exports = router;
