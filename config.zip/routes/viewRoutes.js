const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const User = require('../models/User');
const InvestmentPlan = require('../models/InvestmentPlan');
const Investment = require('../models/Investment');
const Deposit = require('../models/Deposit');
const Withdrawal = require('../models/Withdrawal');
const Transaction = require('../models/Transaction');
const { calculateCurrentReturn } = require('../utils/roiCalculator');

// ===================== PUBLIC ROUTES =====================

// Landing page
router.get('/', (req, res) => {
  res.render('landing', { title: 'InvestWise | Automated AI Trading', user: null });
});

// Login page
router.get('/login', (req, res) => {
  if (req.cookies && req.cookies.token && req.cookies.token !== 'none') {
    return res.redirect('/dashboard');
  }
  res.render('login', { title: 'Login - InvestWise', user: null });
});

// Register page
router.get('/register', (req, res) => {
  if (req.cookies && req.cookies.token && req.cookies.token !== 'none') {
    return res.redirect('/dashboard');
  }
  res.render('register', { title: 'Register - InvestWise', user: null });
});

// Forgot password page
router.get('/forgotpassword', (req, res) => {
  res.render('forgotpassword', { title: 'Forgot Password - InvestWise', user: null });
});

// ===================== PROTECTED USER ROUTES =====================

// User Dashboard
router.get('/dashboard', protect, async (req, res, next) => {
  try {
    const user = req.user;
    if (user.role === 'admin') return res.redirect('/admin');

    const activeInvestments = await Investment.find({ user: user._id, status: 'active' })
      .populate('plan').sort('-createdAt');

    let totalCurrentReturn = 0;
    const investmentsWithReturns = activeInvestments.map(inv => {
      if (inv.plan) {
        const returns = calculateCurrentReturn(inv.amount, inv.plan.roiPercentage, inv.startDate);
        totalCurrentReturn += returns.totalReturn;
        return { ...inv.toObject(), calculatedReturn: returns.totalReturn, dailyReturn: returns.dailyReturn, elapsedDays: returns.elapsedDays };
      }
      return inv.toObject();
    });

    const recentTransactions = await Transaction.find({ user: user._id }).sort('-createdAt').limit(10);
    const activePlans = await InvestmentPlan.find({ status: 'active' }).sort('minAmount');

    res.render('dashboard', {
      title: 'Dashboard - InvestWise',
      user,
      activeInvestments: investmentsWithReturns,
      totalCurrentReturn: Math.round(totalCurrentReturn * 100) / 100,
      recentTransactions,
      activePlans
    });
  } catch (err) {
    next(err);
  }
});

// Investment Plans page
router.get('/plans', protect, async (req, res, next) => {
  try {
    const plans = await InvestmentPlan.find({ status: 'active' }).sort('minAmount');
    res.render('plans', { title: 'Investment Plans - InvestWise', user: req.user, plans });
  } catch (err) {
    next(err);
  }
});

// Deposits page
router.get('/deposits', protect, async (req, res, next) => {
  try {
    const deposits = await Deposit.find({ user: req.user._id }).sort('-createdAt');
    res.render('deposits', { title: 'Deposits - InvestWise', user: req.user, deposits });
  } catch (err) {
    next(err);
  }
});

// Withdrawals page
router.get('/withdrawals', protect, async (req, res, next) => {
  try {
    const withdrawals = await Withdrawal.find({ user: req.user._id }).sort('-createdAt');
    res.render('withdrawals', { title: 'Withdrawals - InvestWise', user: req.user, withdrawals });
  } catch (err) {
    next(err);
  }
});

// Settings page
router.get('/settings', protect, async (req, res, next) => {
  try {
    res.render('settings', { title: 'Account Settings - InvestWise', user: req.user });
  } catch (err) {
    next(err);
  }
});

// ===================== ADMIN ROUTES =====================

// Admin Dashboard
router.get('/admin', protect, authorize('admin'), async (req, res, next) => {
  try {
    const totalUsers = await User.countDocuments({ role: 'user' });
    const activeUsers = await User.countDocuments({ role: 'user', status: 'active' });
    const totalDepositsAgg = await Deposit.aggregate([{ $match: { status: 'approved' } }, { $group: { _id: null, total: { $sum: '$amount' } } }]);
    const totalWithdrawalsAgg = await Withdrawal.aggregate([{ $match: { status: 'approved' } }, { $group: { _id: null, total: { $sum: '$amount' } } }]);
    const activeInvestments = await Investment.countDocuments({ status: 'active' });
    const pendingDeposits = await Deposit.countDocuments({ status: 'pending' });
    const pendingWithdrawals = await Withdrawal.countDocuments({ status: 'pending' });
    const recentTransactions = await Transaction.find().populate('user', 'name email').sort('-createdAt').limit(10);
    const recentUsers = await User.find({ role: 'user' }).sort('-createdAt').limit(5);

    res.render('admin/dashboard', {
      title: 'Admin Dashboard - InvestWise',
      user: req.user,
      stats: {
        totalUsers, activeUsers,
        totalDeposits: totalDepositsAgg[0]?.total || 0,
        totalWithdrawals: totalWithdrawalsAgg[0]?.total || 0,
        activeInvestments, pendingDeposits, pendingWithdrawals
      },
      recentTransactions, recentUsers
    });
  } catch (err) {
    next(err);
  }
});

// Admin Users
router.get('/admin/users', protect, authorize('admin'), async (req, res, next) => {
  try {
    const users = await User.find({ role: 'user' }).sort('-createdAt');
    res.render('admin/users', { title: 'User Management - InvestWise', user: req.user, users });
  } catch (err) {
    next(err);
  }
});

// Admin Plans
router.get('/admin/plans', protect, authorize('admin'), async (req, res, next) => {
  try {
    const plans = await InvestmentPlan.find().sort('-createdAt');
    const activeInvestmentsAgg = await Investment.aggregate([{ $match: { status: 'active' } }, { $group: { _id: null, total: { $sum: '$amount' } } }]);
    const totalSubscribers = await Investment.distinct('user');
    res.render('admin/plans', {
      title: 'Plan Management - InvestWise', user: req.user, plans,
      totalActiveInvestments: activeInvestmentsAgg[0]?.total || 0,
      totalSubscribers: totalSubscribers.length
    });
  } catch (err) {
    next(err);
  }
});

// Admin Deposits
router.get('/admin/deposits', protect, authorize('admin'), async (req, res, next) => {
  try {
    const deposits = await Deposit.find().populate('user', 'name email').sort('-createdAt');
    res.render('admin/deposits', { title: 'Deposit Management - InvestWise', user: req.user, deposits });
  } catch (err) {
    next(err);
  }
});

// Admin Withdrawals
router.get('/admin/withdrawals', protect, authorize('admin'), async (req, res, next) => {
  try {
    const withdrawals = await Withdrawal.find().populate('user', 'name email balance').sort('-createdAt');
    res.render('admin/withdrawals', { title: 'Withdrawal Management - InvestWise', user: req.user, withdrawals });
  } catch (err) {
    next(err);
  }
});

// Admin Analytics
router.get('/admin/analytics', protect, authorize('admin'), async (req, res, next) => {
  try {
    res.render('admin/analytics', { title: 'Analytics - InvestWise', user: req.user });
  } catch (err) {
    next(err);
  }
});

// Admin Settings
router.get('/admin/settings', protect, authorize('admin'), async (req, res, next) => {
  try {
    res.render('admin/settings', { title: 'Platform Settings - InvestWise', user: req.user });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
