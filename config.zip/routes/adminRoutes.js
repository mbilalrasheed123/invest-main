const express = require('express');
const router = express.Router();
const {
  getDashboard, getUsers, updateUserStatus,
  getDeposits, processDeposit,
  getWithdrawals, processWithdrawal,
  createPlan, updatePlan, deletePlan,
  getAnalytics
} = require('../controllers/adminController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect);
router.use(authorize('admin'));

router.get('/dashboard', getDashboard);
router.get('/users', getUsers);
router.put('/users/:id/status', updateUserStatus);
router.get('/deposits', getDeposits);
router.put('/deposits/:id', processDeposit);
router.get('/withdrawals', getWithdrawals);
router.put('/withdrawals/:id', processWithdrawal);
router.post('/plans', createPlan);
router.put('/plans/:id', updatePlan);
router.delete('/plans/:id', deletePlan);
router.get('/analytics', getAnalytics);

module.exports = router;
