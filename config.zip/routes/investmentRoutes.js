const express = require('express');
const router = express.Router();
const { getPlans, createInvestment, getMyInvestments } = require('../controllers/investmentController');
const { protect } = require('../middleware/auth');

router.get('/plans', getPlans); // Public
router.use(protect);
router.post('/', createInvestment);
router.get('/my', getMyInvestments);

module.exports = router;
