/**
 * Calculate daily ROI return for an investment
 * All calculations are server-side only — no frontend manipulation possible
 */

const calculateCurrentReturn = (amount, roiPercentage, startDate) => {
  const now = new Date();
  const start = new Date(startDate);
  const elapsedMs = now - start;
  const elapsedDays = Math.floor(elapsedMs / (1000 * 60 * 60 * 24));

  // Daily ROI = amount * (roiPercentage / 100)
  const dailyReturn = amount * (roiPercentage / 100);
  const totalReturn = dailyReturn * elapsedDays;

  return {
    dailyReturn: Math.round(dailyReturn * 100) / 100,
    totalReturn: Math.round(totalReturn * 100) / 100,
    elapsedDays
  };
};

const calculateProjectedReturn = (amount, roiPercentage, durationDays) => {
  const dailyReturn = amount * (roiPercentage / 100);
  const totalReturn = dailyReturn * durationDays;
  return Math.round(totalReturn * 100) / 100;
};

module.exports = { calculateCurrentReturn, calculateProjectedReturn };
