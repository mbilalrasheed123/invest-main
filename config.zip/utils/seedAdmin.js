const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('../models/User');
const InvestmentPlan = require('../models/InvestmentPlan');

const seedAdmin = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('MongoDB Connected for seeding...');

    // Check if admin already exists
    const existingAdmin = await User.findOne({ role: 'admin' });
    if (existingAdmin) {
      console.log('Admin user already exists. Skipping seed.');
    } else {
      await User.create({
        name: 'Bilal Admin',
        email: 'admin@bilal.com',
        password: 'Admin@123',
        role: 'admin',
        status: 'active'
      });
      console.log('✅ Admin user created: admin@bilal.com / Admin@123');
    }

    // Seed default investment plans if none exist
    const planCount = await InvestmentPlan.countDocuments();
    if (planCount === 0) {
      await InvestmentPlan.insertMany([
        {
          name: 'Starter',
          description: 'Perfect for beginners testing the platform.',
          minAmount: 100,
          maxAmount: 2500,
          roiPercentage: 3,
          durationDays: 30,
          referralBonus: 5,
          supportLevel: 'Standard',
          status: 'active'
        },
        {
          name: 'Pro',
          description: 'For experienced traders seeking higher returns.',
          minAmount: 2501,
          maxAmount: 25000,
          roiPercentage: 4,
          durationDays: 60,
          referralBonus: 8,
          supportLevel: 'Priority',
          status: 'active'
        },
        {
          name: 'Elite',
          description: 'Maximum yield for institutional investors.',
          minAmount: 25001,
          maxAmount: 1000000,
          roiPercentage: 5,
          durationDays: 90,
          referralBonus: 10,
          supportLevel: '24/7 Dedicated',
          status: 'active'
        }
      ]);
      console.log('✅ Default investment plans seeded.');
    } else {
      console.log('Investment plans already exist. Skipping seed.');
    }

    console.log('✅ Seeding complete!');
    process.exit(0);
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  }
};

seedAdmin();
