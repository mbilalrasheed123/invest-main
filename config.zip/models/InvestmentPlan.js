const mongoose = require('mongoose');

const InvestmentPlanSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please add a plan name'],
    trim: true,
    unique: true,
    maxlength: [100, 'Plan name cannot exceed 100 characters']
  },
  description: {
    type: String,
    default: ''
  },
  minAmount: {
    type: Number,
    required: [true, 'Please add a minimum investment amount'],
    min: [0, 'Minimum amount cannot be negative']
  },
  maxAmount: {
    type: Number,
    required: [true, 'Please add a maximum investment amount']
  },
  roiPercentage: {
    type: Number,
    required: [true, 'Please add ROI percentage'],
    min: [0, 'ROI cannot be negative']
  },
  durationDays: {
    type: Number,
    required: [true, 'Please add duration in days'],
    min: [1, 'Duration must be at least 1 day']
  },
  referralBonus: {
    type: Number,
    default: 0
  },
  supportLevel: {
    type: String,
    enum: ['Standard', 'Priority', '24/7 Dedicated'],
    default: 'Standard'
  },
  status: {
    type: String,
    enum: ['active', 'inactive'],
    default: 'active'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('InvestmentPlan', InvestmentPlanSchema);
