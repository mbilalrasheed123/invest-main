const mongoose = require('mongoose');

const InvestmentSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  plan: {
    type: mongoose.Schema.ObjectId,
    ref: 'InvestmentPlan',
    required: true
  },
  amount: {
    type: Number,
    required: [true, 'Please add an investment amount'],
    min: [0, 'Amount cannot be negative']
  },
  projectedReturn: {
    type: Number,
    required: true
  },
  currentReturn: {
    type: Number,
    default: 0
  },
  startDate: {
    type: Date,
    default: Date.now
  },
  endDate: {
    type: Date,
    required: true
  },
  status: {
    type: String,
    enum: ['active', 'completed', 'cancelled'],
    default: 'active'
  },
  lastProfitCalc: {
    type: Date,
    default: Date.now
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Calculate projected return before saving
InvestmentSchema.pre('save', function (next) {
  if (this.isNew) {
    // projectedReturn = amount * (roiPercentage / 100) * durationDays
    // This is set in the controller where we have access to plan details
  }
  next();
});

module.exports = mongoose.model('Investment', InvestmentSchema);
