const path = require('path');
const express = require('express');
const dotenv = require('dotenv');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const mongoSanitize = require('express-mongo-sanitize');

// Load env vars
dotenv.config();

// Connect to database
const connectDB = require('./config/db');

// Route files
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const investmentRoutes = require('./routes/investmentRoutes');
const depositRoutes = require('./routes/depositRoutes');
const withdrawalRoutes = require('./routes/withdrawalRoutes');
const adminRoutes = require('./routes/adminRoutes');
const viewRoutes = require('./routes/viewRoutes');

// Middleware
const errorHandler = require('./middleware/errorHandler');

const app = express();

// Body parser
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Cookie parser
app.use(cookieParser());

// Security: Helmet (with relaxed CSP for Tailwind CDN and Google Fonts)
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://cdn.tailwindcss.com"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https://lh3.googleusercontent.com", "https://*.googleusercontent.com"],
      connectSrc: ["'self'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));

// Security: CORS
app.use(cors({
  origin: process.env.NODE_ENV === 'production' ? process.env.FRONTEND_URL : '*',
  credentials: true
}));

// Security: Rate limiting on auth routes
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  message: { success: false, error: 'Too many requests. Please try again after 15 minutes.' }
});

// Security: General rate limiting
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200
});

app.use('/api/', generalLimiter);
app.use('/api/auth/', authLimiter);

// Security: Sanitize data (prevent NoSQL injection)
app.use(mongoSanitize());

// Compression
app.use(compression());

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Mount routes
app.use('/', viewRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/investments', investmentRoutes);
app.use('/api/deposits', depositRoutes);
app.use('/api/withdrawals', withdrawalRoutes);
app.use('/api/admin', adminRoutes);

// Error handler
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

// Connect DB and start server
const startServer = async () => {
  await connectDB();

  // Auto-seed admin on first run
  const User = require('./models/User');
  const adminExists = await User.findOne({ role: 'admin' });
  if (!adminExists) {
    await User.create({
      name: 'Bilal Admin',
      email: 'admin@bilal.com',
      password: 'Admin@123',
      role: 'admin',
      status: 'active'
    });
    console.log('✅ Admin seeded: admin@bilal.com / Admin@123');
  }

  // Auto-seed investment plans
  const InvestmentPlan = require('./models/InvestmentPlan');
  const planCount = await InvestmentPlan.countDocuments();
  if (planCount === 0) {
    await InvestmentPlan.insertMany([
      { name: 'Starter', description: 'Perfect for beginners testing the platform.', minAmount: 100, maxAmount: 2500, roiPercentage: 3, durationDays: 30, referralBonus: 5, supportLevel: 'Standard', status: 'active' },
      { name: 'Pro', description: 'For experienced traders seeking higher returns.', minAmount: 2501, maxAmount: 25000, roiPercentage: 4, durationDays: 60, referralBonus: 8, supportLevel: 'Priority', status: 'active' },
      { name: 'Elite', description: 'Maximum yield for institutional investors.', minAmount: 25001, maxAmount: 1000000, roiPercentage: 5, durationDays: 90, referralBonus: 10, supportLevel: '24/7 Dedicated', status: 'active' }
    ]);
    console.log('✅ Default investment plans seeded');
  }

  app.listen(PORT, () => {
    console.log(`🚀 Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
    console.log(`📡 Visit: http://localhost:${PORT}`);
  });
};

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
