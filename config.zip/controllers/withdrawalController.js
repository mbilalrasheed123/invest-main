const Withdrawal = require('../models/Withdrawal');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const ErrorResponse = require('../utils/ErrorResponse');

// @desc    Create withdrawal request
// @route   POST /api/withdrawals
exports.createWithdrawal = async (req, res, next) => {
  try {
    const { amount, walletAddress, paymentMethod } = req.body;

    const withdrawAmount = parseFloat(amount);
    if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
      return next(new ErrorResponse('Please provide a valid withdrawal amount', 400));
    }

    // Check user balance
    const user = await User.findById(req.user.id);
    if (user.balance < withdrawAmount) {
      return next(new ErrorResponse('Insufficient balance for this withdrawal', 400));
    }

    // Check for existing pending withdrawal to prevent duplicates
    const pendingWithdrawal = await Withdrawal.findOne({
      user: req.user.id,
      status: 'pending'
    });

    if (pendingWithdrawal) {
      return next(new ErrorResponse('You already have a pending withdrawal request. Please wait for it to be processed.', 400));
    }

    const withdrawal = await Withdrawal.create({
      user: req.user.id,
      amount: withdrawAmount,
      walletAddress: walletAddress || '',
      paymentMethod: paymentMethod || 'Bank Transfer'
    });

    // Log transaction as pending
    await Transaction.create({
      user: req.user.id,
      type: 'withdrawal',
      amount: withdrawAmount,
      status: 'pending',
      reference: withdrawal._id,
      referenceModel: 'Withdrawal',
      description: `Withdrawal request of $${withdrawAmount}`
    });

    res.status(201).json({
      success: true,
      data: withdrawal,
      message: 'Withdrawal request submitted. Awaiting admin approval.'
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get user's withdrawals
// @route   GET /api/withdrawals/my
exports.getMyWithdrawals = async (req, res, next) => {
  try {
    const withdrawals = await Withdrawal.find({ user: req.user.id }).sort('-createdAt');
    res.status(200).json({ success: true, count: withdrawals.length, data: withdrawals });
  } catch (err) {
    next(err);
  }
};
