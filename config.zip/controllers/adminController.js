const User = require('../models/User');
const InvestmentPlan = require('../models/InvestmentPlan');
const Investment = require('../models/Investment');
const Deposit = require('../models/Deposit');
const Withdrawal = require('../models/Withdrawal');
const Transaction = require('../models/Transaction');
const ErrorResponse = require('../utils/ErrorResponse');

// @desc    Get admin dashboard stats
// @route   GET /api/admin/dashboard
exports.getDashboard = async (req, res, next) => {
  try {
    const totalUsers = await User.countDocuments({ role: 'user' });
    const activeUsers = await User.countDocuments({ role: 'user', status: 'active' });
    const totalDeposits = await Deposit.aggregate([
      { $match: { status: 'approved' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);
    const totalWithdrawals = await Withdrawal.aggregate([
      { $match: { status: 'approved' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);
    const activeInvestments = await Investment.countDocuments({ status: 'active' });
    const pendingDeposits = await Deposit.countDocuments({ status: 'pending' });
    const pendingWithdrawals = await Withdrawal.countDocuments({ status: 'pending' });

    const recentTransactions = await Transaction.find()
      .populate('user', 'name email')
      .sort('-createdAt')
      .limit(10);

    const recentUsers = await User.find({ role: 'user' })
      .sort('-createdAt')
      .limit(5);

    res.status(200).json({
      success: true,
      data: {
        totalUsers,
        activeUsers,
        totalDeposits: totalDeposits[0]?.total || 0,
        totalWithdrawals: totalWithdrawals[0]?.total || 0,
        activeInvestments,
        pendingDeposits,
        pendingWithdrawals,
        recentTransactions,
        recentUsers
      }
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get all users
// @route   GET /api/admin/users
exports.getUsers = async (req, res, next) => {
  try {
    const users = await User.find({ role: 'user' }).sort('-createdAt');
    res.status(200).json({ success: true, count: users.length, data: users });
  } catch (err) {
    next(err);
  }
};

// @desc    Update user status
// @route   PUT /api/admin/users/:id/status
exports.updateUserStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    if (!['active', 'suspended', 'banned'].includes(status)) {
      return next(new ErrorResponse('Invalid status value', 400));
    }

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    );

    if (!user) {
      return next(new ErrorResponse('User not found', 404));
    }

    res.status(200).json({ success: true, data: user });
  } catch (err) {
    next(err);
  }
};

// @desc    Get all deposits
// @route   GET /api/admin/deposits
exports.getDeposits = async (req, res, next) => {
  try {
    const status = req.query.status || null;
    const filter = status ? { status } : {};
    const deposits = await Deposit.find(filter)
      .populate('user', 'name email')
      .sort('-createdAt');
    res.status(200).json({ success: true, count: deposits.length, data: deposits });
  } catch (err) {
    next(err);
  }
};

// @desc    Process deposit (approve/reject)
// @route   PUT /api/admin/deposits/:id
exports.processDeposit = async (req, res, next) => {
  try {
    const { status, adminNote } = req.body;
    if (!['approved', 'rejected'].includes(status)) {
      return next(new ErrorResponse('Invalid status. Use approved or rejected.', 400));
    }

    const deposit = await Deposit.findById(req.params.id);
    if (!deposit) {
      return next(new ErrorResponse('Deposit not found', 404));
    }

    if (deposit.status !== 'pending') {
      return next(new ErrorResponse('This deposit has already been processed', 400));
    }

    deposit.status = status;
    deposit.adminNote = adminNote || '';
    deposit.processedBy = req.user.id;
    deposit.processedAt = Date.now();
    await deposit.save();

    // If approved, update user balance
    if (status === 'approved') {
      const user = await User.findById(deposit.user);
      user.balance += deposit.amount;
      user.totalDeposited += deposit.amount;
      await user.save({ validateBeforeSave: false });

      // Update transaction status
      await Transaction.findOneAndUpdate(
        { reference: deposit._id, type: 'deposit' },
        { status: 'completed' }
      );
    } else {
      await Transaction.findOneAndUpdate(
        { reference: deposit._id, type: 'deposit' },
        { status: 'failed' }
      );
    }

    res.status(200).json({ success: true, data: deposit });
  } catch (err) {
    next(err);
  }
};

// @desc    Get all withdrawals
// @route   GET /api/admin/withdrawals
exports.getWithdrawals = async (req, res, next) => {
  try {
    const status = req.query.status || null;
    const filter = status ? { status } : {};
    const withdrawals = await Withdrawal.find(filter)
      .populate('user', 'name email balance')
      .sort('-createdAt');
    res.status(200).json({ success: true, count: withdrawals.length, data: withdrawals });
  } catch (err) {
    next(err);
  }
};

// @desc    Process withdrawal (approve/reject)
// @route   PUT /api/admin/withdrawals/:id
exports.processWithdrawal = async (req, res, next) => {
  try {
    const { status, adminNote } = req.body;
    if (!['approved', 'rejected'].includes(status)) {
      return next(new ErrorResponse('Invalid status. Use approved or rejected.', 400));
    }

    const withdrawal = await Withdrawal.findById(req.params.id);
    if (!withdrawal) {
      return next(new ErrorResponse('Withdrawal not found', 404));
    }

    if (withdrawal.status !== 'pending') {
      return next(new ErrorResponse('This withdrawal has already been processed', 400));
    }

    const user = await User.findById(withdrawal.user);

    if (status === 'approved') {
      // Verify user still has sufficient balance
      if (user.balance < withdrawal.amount) {
        return next(new ErrorResponse('User has insufficient balance for this withdrawal', 400));
      }
      user.balance -= withdrawal.amount;
      user.totalWithdrawn += withdrawal.amount;
      await user.save({ validateBeforeSave: false });

      await Transaction.findOneAndUpdate(
        { reference: withdrawal._id, type: 'withdrawal' },
        { status: 'completed' }
      );
    } else {
      await Transaction.findOneAndUpdate(
        { reference: withdrawal._id, type: 'withdrawal' },
        { status: 'failed' }
      );
    }

    withdrawal.status = status;
    withdrawal.adminNote = adminNote || '';
    withdrawal.processedBy = req.user.id;
    withdrawal.processedAt = Date.now();
    await withdrawal.save();

    res.status(200).json({ success: true, data: withdrawal });
  } catch (err) {
    next(err);
  }
};

// @desc    Create investment plan
// @route   POST /api/admin/plans
exports.createPlan = async (req, res, next) => {
  try {
    const plan = await InvestmentPlan.create(req.body);
    res.status(201).json({ success: true, data: plan });
  } catch (err) {
    next(err);
  }
};

// @desc    Update investment plan
// @route   PUT /api/admin/plans/:id
exports.updatePlan = async (req, res, next) => {
  try {
    const plan = await InvestmentPlan.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!plan) {
      return next(new ErrorResponse('Plan not found', 404));
    }

    res.status(200).json({ success: true, data: plan });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete investment plan
// @route   DELETE /api/admin/plans/:id
exports.deletePlan = async (req, res, next) => {
  try {
    const plan = await InvestmentPlan.findById(req.params.id);
    if (!plan) {
      return next(new ErrorResponse('Plan not found', 404));
    }

    // Check if any active investments use this plan
    const activeInvestments = await Investment.countDocuments({ plan: req.params.id, status: 'active' });
    if (activeInvestments > 0) {
      return next(new ErrorResponse(`Cannot delete plan with ${activeInvestments} active investments. Deactivate it instead.`, 400));
    }

    await InvestmentPlan.findByIdAndDelete(req.params.id);
    res.status(200).json({ success: true, data: {} });
  } catch (err) {
    next(err);
  }
};

// @desc    Get analytics
// @route   GET /api/admin/analytics
exports.getAnalytics = async (req, res, next) => {
  try {
    // Monthly deposit trends
    const depositTrends = await Deposit.aggregate([
      { $match: { status: 'approved' } },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m', date: '$createdAt' } },
          total: { $sum: '$amount' },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: -1 } },
      { $limit: 12 }
    ]);

    // User registration trends
    const userTrends = await User.aggregate([
      { $match: { role: 'user' } },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m', date: '$createdAt' } },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: -1 } },
      { $limit: 12 }
    ]);

    // Plan distribution
    const planDistribution = await Investment.aggregate([
      { $match: { status: 'active' } },
      {
        $group: {
          _id: '$plan',
          totalAmount: { $sum: '$amount' },
          count: { $sum: 1 }
        }
      }
    ]);

    res.status(200).json({
      success: true,
      data: { depositTrends, userTrends, planDistribution }
    });
  } catch (err) {
    next(err);
  }
};
