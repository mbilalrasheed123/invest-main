const InvestmentPlan = require('../models/InvestmentPlan');
const Investment = require('../models/Investment');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const ErrorResponse = require('../utils/ErrorResponse');
const { calculateProjectedReturn, calculateCurrentReturn } = require('../utils/roiCalculator');

// @desc    Get all active investment plans
// @route   GET /api/investments/plans
exports.getPlans = async (req, res, next) => {
  try {
    const plans = await InvestmentPlan.find({ status: 'active' }).sort('minAmount');
    res.status(200).json({ success: true, count: plans.length, data: plans });
  } catch (err) {
    next(err);
  }
};

// @desc    Create new investment
// @route   POST /api/investments
exports.createInvestment = async (req, res, next) => {
  try {
    const { planId, amount } = req.body;

    // Get the plan
    const plan = await InvestmentPlan.findById(planId);
    if (!plan) {
      return next(new ErrorResponse('Investment plan not found', 404));
    }

    if (plan.status !== 'active') {
      return next(new ErrorResponse('This investment plan is currently inactive', 400));
    }

    // Validate amount
    const investAmount = parseFloat(amount);
    if (isNaN(investAmount) || investAmount <= 0) {
      return next(new ErrorResponse('Please provide a valid investment amount', 400));
    }

    if (investAmount < plan.minAmount) {
      return next(new ErrorResponse(`Minimum investment for this plan is $${plan.minAmount}`, 400));
    }

    if (investAmount > plan.maxAmount) {
      return next(new ErrorResponse(`Maximum investment for this plan is $${plan.maxAmount}`, 400));
    }

    // Check user balance
    const user = await User.findById(req.user.id);
    if (user.balance < investAmount) {
      return next(new ErrorResponse('Insufficient balance. Please deposit funds first.', 400));
    }

    // Calculate projected return (server-side only)
    const projectedReturn = calculateProjectedReturn(investAmount, plan.roiPercentage, plan.durationDays);

    // Calculate end date
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + plan.durationDays);

    // Create investment
    const investment = await Investment.create({
      user: req.user.id,
      plan: plan._id,
      amount: investAmount,
      projectedReturn,
      endDate
    });

    // Deduct balance and update totals
    user.balance -= investAmount;
    user.totalInvested += investAmount;
    await user.save({ validateBeforeSave: false });

    // Log transaction
    await Transaction.create({
      user: req.user.id,
      type: 'investment',
      amount: investAmount,
      status: 'completed',
      reference: investment._id,
      referenceModel: 'Investment',
      description: `Invested $${investAmount} in ${plan.name} plan`
    });

    res.status(201).json({
      success: true,
      data: investment,
      message: `Successfully invested $${investAmount} in ${plan.name} plan`
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get user's investments
// @route   GET /api/investments/my
exports.getMyInvestments = async (req, res, next) => {
  try {
    const investments = await Investment.find({ user: req.user.id })
      .populate('plan')
      .sort('-createdAt');

    // Calculate real-time returns
    const investmentsWithReturns = investments.map(inv => {
      if (inv.status === 'active' && inv.plan) {
        const returns = calculateCurrentReturn(inv.amount, inv.plan.roiPercentage, inv.startDate);
        return {
          ...inv.toObject(),
          calculatedReturn: returns.totalReturn,
          dailyReturn: returns.dailyReturn,
          elapsedDays: returns.elapsedDays
        };
      }
      return inv.toObject();
    });

    res.status(200).json({
      success: true,
      count: investments.length,
      data: investmentsWithReturns
    });
  } catch (err) {
    next(err);
  }
};
