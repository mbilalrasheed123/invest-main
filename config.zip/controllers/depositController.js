const Deposit = require('../models/Deposit');
const Transaction = require('../models/Transaction');
const ErrorResponse = require('../utils/ErrorResponse');

// @desc    Create deposit request
// @route   POST /api/deposits
exports.createDeposit = async (req, res, next) => {
  try {
    const { amount, paymentMethod } = req.body;

    const depositAmount = parseFloat(amount);
    if (isNaN(depositAmount) || depositAmount <= 0) {
      return next(new ErrorResponse('Please provide a valid deposit amount', 400));
    }

    const depositData = {
      user: req.user.id,
      amount: depositAmount,
      paymentMethod: paymentMethod || 'Bank Transfer'
    };

    // Handle file upload
    if (req.file) {
      depositData.paymentProof = `/uploads/${req.file.filename}`;
    }

    const deposit = await Deposit.create(depositData);

    // Log transaction as pending
    await Transaction.create({
      user: req.user.id,
      type: 'deposit',
      amount: depositAmount,
      status: 'pending',
      reference: deposit._id,
      referenceModel: 'Deposit',
      description: `Deposit request of $${depositAmount}`
    });

    res.status(201).json({
      success: true,
      data: deposit,
      message: 'Deposit request submitted. Awaiting admin approval.'
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get user's deposits
// @route   GET /api/deposits/my
exports.getMyDeposits = async (req, res, next) => {
  try {
    const deposits = await Deposit.find({ user: req.user.id }).sort('-createdAt');
    res.status(200).json({ success: true, count: deposits.length, data: deposits });
  } catch (err) {
    next(err);
  }
};
