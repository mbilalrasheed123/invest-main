const User = require('../models/User');
const Investment = require('../models/Investment');
const Transaction = require('../models/Transaction');
const Deposit = require('../models/Deposit');
const Withdrawal = require('../models/Withdrawal');
const InvestmentPlan = require('../models/InvestmentPlan');
const ErrorResponse = require('../utils/ErrorResponse');
const { calculateCurrentReturn } = require('../utils/roiCalculator');

// @desc    Get user dashboard data
// @route   GET /api/user/dashboard
exports.getDashboard = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);

    // Get active investments with plan details
    const activeInvestments = await Investment.find({ user: req.user.id, status: 'active' })
      .populate('plan')
      .sort('-createdAt');

    // Calculate real-time returns for each active investment
    let totalCurrentReturn = 0;
    const investmentsWithReturns = activeInvestments.map(inv => {
      const returns = calculateCurrentReturn(inv.amount, inv.plan.roiPercentage, inv.startDate);
      totalCurrentReturn += returns.totalReturn;
      return {
        ...inv.toObject(),
        calculatedReturn: returns.totalReturn,
        dailyReturn: returns.dailyReturn,
        elapsedDays: returns.elapsedDays
      };
    });

    // Recent transactions
    const recentTransactions = await Transaction.find({ user: req.user.id })
      .sort('-createdAt')
      .limit(10);

    // Get active plans for investing
    const activePlans = await InvestmentPlan.find({ status: 'active' }).sort('minAmount');

    // Pending deposits/withdrawals
    const pendingDeposits = await Deposit.countDocuments({ user: req.user.id, status: 'pending' });
    const pendingWithdrawals = await Withdrawal.countDocuments({ user: req.user.id, status: 'pending' });

    res.status(200).json({
      success: true,
      data: {
        user,
        activeInvestments: investmentsWithReturns,
        totalCurrentReturn: Math.round(totalCurrentReturn * 100) / 100,
        recentTransactions,
        activePlans,
        pendingDeposits,
        pendingWithdrawals
      }
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Get user profile
// @route   GET /api/user/profile
exports.getProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    res.status(200).json({ success: true, data: user });
  } catch (err) {
    next(err);
  }
};

// @desc    Update profile
// @route   PUT /api/user/profile
exports.updateProfile = async (req, res, next) => {
  try {
    const fieldsToUpdate = {
      name: req.body.name,
      email: req.body.email
    };

    // Remove undefined values
    Object.keys(fieldsToUpdate).forEach(key =>
      fieldsToUpdate[key] === undefined && delete fieldsToUpdate[key]
    );

    const user = await User.findByIdAndUpdate(req.user.id, fieldsToUpdate, {
      new: true,
      runValidators: true
    });

    res.status(200).json({ success: true, data: user });
  } catch (err) {
    next(err);
  }
};

// @desc    Update password
// @route   PUT /api/user/updatepassword
exports.updatePassword = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).select('+password');

    if (!(await user.matchPassword(req.body.currentPassword))) {
      return next(new ErrorResponse('Current password is incorrect', 401));
    }

    if (req.body.newPassword !== req.body.confirmPassword) {
      return next(new ErrorResponse('Passwords do not match', 400));
    }

    user.password = req.body.newPassword;
    await user.save();

    res.status(200).json({ success: true, message: 'Password updated successfully' });
  } catch (err) {
    next(err);
  }
};
