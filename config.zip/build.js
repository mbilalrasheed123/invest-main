const fs = require('fs');
const path = require('path');

const SRC = __dirname;
const DIST = path.join(__dirname, 'dist');

// Folders to copy into dist
const COPY_DIRS = ['config', 'controllers', 'middleware', 'models', 'routes', 'utils', 'views', 'public'];
// Root files to copy
const COPY_FILES = ['server.js', '.gitignore'];
// Folders/files to exclude
const EXCLUDE = ['node_modules', 'dist', 'backup', 'stitch', '.env', '.env.example', 'build.js', 'package.json', 'package-lock.json'];

// ── Helpers ──────────────────────────────────────────
function cleanDir(dir) {
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
  }
  fs.mkdirSync(dir, { recursive: true });
}

function copyDirRecursive(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDirRecursive(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

// ── Main Build ──────────────────────────────────────
console.log('🔨 Building InvestWise for production...\n');

// 1. Clean dist
console.log('  ✦ Cleaning dist folder...');
cleanDir(DIST);

// 2. Copy application folders
for (const dir of COPY_DIRS) {
  const srcDir = path.join(SRC, dir);
  if (fs.existsSync(srcDir)) {
    console.log(`  ✦ Copying ${dir}/`);
    copyDirRecursive(srcDir, path.join(DIST, dir));
  }
}

// 3. Copy root files
for (const file of COPY_FILES) {
  const srcFile = path.join(SRC, file);
  if (fs.existsSync(srcFile)) {
    console.log(`  ✦ Copying ${file}`);
    fs.copyFileSync(srcFile, path.join(DIST, file));
  }
}

// 4. Create production package.json
console.log('  ✦ Creating production package.json...');
const pkg = require('./package.json');
const prodPkg = {
  name: pkg.name,
  version: pkg.version,
  description: pkg.description,
  main: 'server.js',
  scripts: {
    start: 'node server.js'
  },
  author: pkg.author,
  license: pkg.license,
  dependencies: pkg.dependencies,
  engines: {
    node: '>=18.0.0'
  }
};
fs.writeFileSync(path.join(DIST, 'package.json'), JSON.stringify(prodPkg, null, 2));

// 5. Create .env.example
console.log('  ✦ Creating .env.example...');
const envExample = `# InvestWise Production Environment Variables
# Set these as environment variables on your deployment platform

PORT=5000
NODE_ENV=production

# MongoDB Atlas Connection String (FREE)
# Get yours at https://www.mongodb.com/atlas
MONGODB_URI=mongodb+srv://your_user:your_password@cluster0.xxxxx.mongodb.net/investwise?retryWrites=true&w=majority

# JWT Config — CHANGE THESE IN PRODUCTION
JWT_SECRET=change_this_to_a_random_secret_string
JWT_EXPIRE=30d
JWT_COOKIE_EXPIRE=30
`;
fs.writeFileSync(path.join(DIST, '.env.example'), envExample);

// 6. Create Procfile
console.log('  ✦ Creating Procfile...');
fs.writeFileSync(path.join(DIST, 'Procfile'), 'web: node server.js\n');

// 7. Create render.yaml
console.log('  ✦ Creating render.yaml...');
const renderYaml = `services:
  - type: web
    name: investwise-platform
    runtime: node
    plan: free
    buildCommand: npm install
    startCommand: node server.js
    envVars:
      - key: NODE_ENV
        value: production
      - key: MONGODB_URI
        sync: false
      - key: JWT_SECRET
        generateValue: true
      - key: JWT_EXPIRE
        value: 30d
      - key: JWT_COOKIE_EXPIRE
        value: 30
`;
fs.writeFileSync(path.join(DIST, 'render.yaml'), renderYaml);

// 8. Create README.md
console.log('  ✦ Creating README.md...');
const readme = `# InvestWise — AI-Powered Investment Platform

## Deploy

### Render (Free)
1. Push this folder to GitHub
2. Go to render.com → New Web Service → Connect repo
3. Add env var MONGODB_URI (get free at mongodb.com/atlas)
4. Deploy!

### Railway
1. Push to GitHub → railway.app → New Project → Connect
2. Add env vars → Deploy

## Environment Variables
- MONGODB_URI — MongoDB Atlas connection string
- JWT_SECRET — Any random secret string
- JWT_EXPIRE — 30d
- JWT_COOKIE_EXPIRE — 30
- NODE_ENV — production

## Admin Login
- Email: admin@bilal.com
- Password: Admin@123
`;
fs.writeFileSync(path.join(DIST, 'README.md'), readme);

// 9. Ensure uploads dir exists
fs.mkdirSync(path.join(DIST, 'public', 'uploads'), { recursive: true });
fs.writeFileSync(path.join(DIST, 'public', 'uploads', '.gitkeep'), '');

// Count files
let fileCount = 0;
function countFiles(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const e of entries) {
    if (e.isDirectory()) countFiles(path.join(dir, e.name));
    else fileCount++;
  }
}
countFiles(DIST);

console.log(`\n✅ Build complete! ${fileCount} files → dist/`);
console.log('\n📦 Next steps:');
console.log('   cd dist');
console.log('   npm install');
console.log('   Then push to GitHub and deploy on Render/Railway\n');
